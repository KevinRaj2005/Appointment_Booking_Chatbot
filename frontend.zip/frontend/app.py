import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.chatbot import get_bot_response
import streamlit as st
from backend.chatbot import get_bot_response

st.set_page_config(page_title="Appointment Assistant", page_icon="💬")
st.markdown("<h1 style='text-align: center;'>💬 Appointment Assistant</h1>", unsafe_allow_html=True)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Chat bubble style
def chat_bubble(message, is_user=False):
    bg_color = "#DCF8C6" if is_user else "#E4E6EB"
    align = "flex-end" if is_user else "flex-start"
    text_color = "#000000"
    st.markdown(
        f"""
        <div style='display: flex; justify-content: {align};'>
            <div style='background-color: {bg_color}; padding: 12px; border-radius: 10px; margin: 6px; max-width: 80%; color: {text_color}; font-size: 16px;'>
                {message}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

# Display previous messages
for entry in st.session_state.messages:
    chat_bubble(entry["message"], is_user=entry["is_user"])

# Input box
user_input = st.chat_input("Type your message...")

if user_input:
    # Show user message
    st.session_state.messages.append({"message": user_input, "is_user": True})
    chat_bubble(user_input, is_user=True)

    # Get bot response
    bot_response = get_bot_response(user_input)
    st.session_state.messages.append({"message": bot_response, "is_user": False})
    chat_bubble(bot_response, is_user=False)

    st.rerun()
        