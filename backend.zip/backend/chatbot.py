# ✅ chatbot.py (backend/chatbot.py)
import os
import streamlit as st
from dotenv import load_dotenv
from langchain.chat_models import ChatOllama
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory

# ✅ Load environment variables
load_dotenv()
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = os.getenv("LANGCHAIN_API_KEY")
os.environ["LANGCHAIN_ENDPOINT"] = "https://api.smith.langchain.com"

# ✅ LLM & Prompt Setup
llm = ChatOllama(model="llama2")
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

prompt = PromptTemplate(
    input_variables=["input"],
    template="""
You are a helpful and friendly assistant that helps users book appointments.

DO:
- Use what you already know (name/date/time) and don't ask again.
- Ask ONLY for missing parts (like time if name & date are known).
- Use friendly tone, brief replies, and occasional emojis.
- Respect when user cancels or changes mind.
- Avoid repeating greetings or introducing yourself more than once.

--- Conversation & Context ---
{input}
"""
)

chain = LLMChain(llm=llm, prompt=prompt, memory=memory)

# ✅ Imports
from backend.rag import get_rag_qa_chain
from backend.intent import detect_intent
from backend.calendar import create_event

qa_chain = get_rag_qa_chain()

# ✅ Session state initialization
if "booking_state" not in st.session_state:
    st.session_state.booking_state = {"name": None, "date": None, "time": None}
if "booking_cancelled" not in st.session_state:
    st.session_state.booking_cancelled = False
if "greeted" not in st.session_state:
    st.session_state.greeted = False
if "confirmed" not in st.session_state:
    st.session_state.confirmed = False

def is_info_query(text):
    return detect_intent(text) == "info"

def get_bot_response(user_input: str):
    lowered = user_input.lower()
    state = st.session_state.booking_state

    # ✅ Mood detection & cancellation
    if any(kw in lowered for kw in ["never mind", "later", "not now", "cancel", "i'll try later"]):
        st.session_state.booking_cancelled = True
        st.session_state.booking_state = {"name": None, "date": None, "time": None}
        st.session_state.confirmed = False
        return "No worries 😊 — we’ll be here whenever you're ready to book! Just let me know."

    # ✅ Handle polite exits
    if st.session_state.booking_cancelled and lowered in ["thanks", "thank you", "no"]:
        return "You're welcome! 👋 Let me know if you'd like to schedule later."

    # ✅ Reset flow if user re-initiates
    if st.session_state.booking_cancelled and any(kw in lowered for kw in ["book", "appointment", "schedule"]):
        st.session_state.booking_cancelled = False
        st.session_state.booking_state = {"name": None, "date": None, "time": None}
        st.session_state.confirmed = False

    # 🧠 RAG if info query
    if is_info_query(user_input):
        return qa_chain.run(user_input)

    # ✅ Extract booking info
    if not state["name"] and len(user_input.split()) <= 3:
        state["name"] = user_input.title()
    elif not state["date"] and ("tomorrow" in lowered or "today" in lowered or any(char.isdigit() for char in user_input)):
        state["date"] = user_input.strip()
    elif not state["time"] and (":" in lowered or "am" in lowered or "pm" in lowered or "around" in lowered):
        state["time"] = user_input.strip()

    # ✅ Final confirmation intent
    if lowered in ["confirm", "yes", "book it", "please confirm", "schedule it"] and all(state.values()):
        if not st.session_state.confirmed:
            create_event(state["name"], state["date"], state["time"])
            st.session_state.confirmed = True
            return f"✅ Your appointment has been successfully booked and added to your calendar, {state['name']}! Let me know if you need anything else."
        else:
            return "Your appointment is already confirmed ✅. Let me know if you'd like to reschedule or cancel."

    # ✅ Show summary if all collected and not confirmed
    if all(state.values()) and not st.session_state.confirmed:
        return f"Thanks {state['name']}! ✅ I've noted your appointment for **{state['date']}** at **{state['time']}**. Let me know if you'd like to confirm, reschedule, or cancel."

    # ✅ Build prompt input for missing fields
    collected_info = []
    if state["name"]:
        collected_info.append(f"Name: {state['name']}")
    if state["date"]:
        collected_info.append(f"Date: {state['date']}")
    if state["time"]:
        collected_info.append(f"Time: {state['time']}")
    summary = "\n".join(collected_info) or "(none yet)"

    missing = []
    if not state["name"]: missing.append("name")
    if not state["date"]: missing.append("date")
    if not state["time"]: missing.append("time")
    task = f"Please collect: {', '.join(missing)}." if missing else "All details collected."

    greeting_prefix = "" if st.session_state.greeted else "Hi there! 👋 "
    st.session_state.greeted = True

    prompt_input = f"""
{greeting_prefix}User said: {user_input}
Current Booking Info:
{summary}
{task}
"""

    return chain.run(input=prompt_input)
