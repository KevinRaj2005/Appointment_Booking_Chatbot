import os
from langchain.vectorstores import FAISS
from langchain.embeddings import OllamaEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders import TextLoader
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOllama

def get_rag_qa_chain():
    knowledge_path = "backend/docs/knowledge.txt"

    # Step 1: Check if file exists
    if not os.path.exists(knowledge_path):
        raise FileNotFoundError(f"❌ knowledge.txt not found at: {knowledge_path}")

    # Step 2: Load documents
    loader = TextLoader(knowledge_path)
    docs = loader.load()
    if not docs:
        raise RuntimeError("❌ knowledge.txt is empty or unreadable. Please add content.")

    # Step 3: Split documents
    splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    chunks = splitter.split_documents(docs)
    if not chunks:
        raise RuntimeError("❌ Document splitting failed. Check if knowledge.txt has content.")

    # Step 4: Create embeddings and FAISS
    embeddings = OllamaEmbeddings(model="nomic-embed-text")
    db = FAISS.from_documents(chunks, embeddings)

    retriever = db.as_retriever(search_type="similarity", k=3)

    # Step 5: QA chain setup
    qa = RetrievalQA.from_chain_type(
        llm=ChatOllama(model="llama2"),
        retriever=retriever,
        return_source_documents=False
    )

    return qa
 