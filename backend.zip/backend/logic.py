import json
import os
from backend.calendar import create_event

BOOKING_FILE = "data/bookings.json"

def detect_intent(text):
    booking_keywords = ["book", "appointment", "schedule", "reserve", "meet"]
    info_keywords = ["what", "how", "tell", "can", "do you", "services"]

    text = text.lower()
    if any(k in text for k in booking_keywords):
        return "booking"
    elif any(k in text for k in info_keywords):
        return "info"
    else:
        return "unknown"

def save_booking(name, date, time, email="youremail@example.com"):
    booking = {"name": name, "date": date, "time": time}
    if not os.path.exists(BOOKING_FILE):
        with open(BOOKING_FILE, "w") as f:
            json.dump([booking], f, indent=2)
    else:
        with open(BOOKING_FILE, "r+") as f:
            data = json.load(f)
            data.append(booking)
            f.seek(0)
            json.dump(data, f, indent=2)
    result = create_event(name, date, time, email)
    return "✅ Booking saved! " + result

