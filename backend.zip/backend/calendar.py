# ✅ calendar.py (backend/calendar.py)
from __future__ import print_function
import os
import pickle
from datetime import datetime, timedelta
from dateutil import parser
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# ✅ If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/calendar.events']

def create_event(name, date_str, time_str):
    # ✅ Handle relative dates like 'tomorrow'
    lowered = date_str.strip().lower()
    if lowered == "tomorrow":
        date = datetime.now().date() + timedelta(days=1)
    elif lowered == "today":
        date = datetime.now().date()
    else:
        date = parser.parse(date_str, fuzzy=True).date()

    # ✅ Time parsing with fuzzy
    time = parser.parse(time_str, fuzzy=True).time()

    # ✅ Combine into datetime objects
    start_datetime = datetime.combine(date, time)
    end_datetime = start_datetime + timedelta(minutes=30)

    # ✅ Load credentials
    creds = None
    token_path = 'token.json'
    creds_path = 'credentials.json'

    if os.path.exists(token_path):
        with open(token_path, 'rb') as token:
            creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(creds_path, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(token_path, 'w') as token:
            token.write(creds.to_json())

    # ✅ Build Google Calendar API service
    service = build('calendar', 'v3', credentials=creds)

    # ✅ Create the event object
    event = {
        'summary': f'Appointment with {name}',
        'start': {
            'dateTime': start_datetime.isoformat(),
            'timeZone': 'Asia/Kolkata',
        },
        'end': {
            'dateTime': end_datetime.isoformat(),
            'timeZone': 'Asia/Kolkata',
        },
    }

    # ✅ Insert the event into the calendar
    created_event = service.events().insert(calendarId='primary', body=event).execute()
    print(f"✅ Event created: {created_event.get('htmlLink')}")
    return f"Event created: {created_event.get('htmlLink')}"