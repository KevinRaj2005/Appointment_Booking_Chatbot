def detect_intent(user_input: str) -> str:
    lowered = user_input.lower()
    info_keywords = ["what", "how", "can you tell", "explain", "information", "details", "availability", "slots"]

    if any(kw in lowered for kw in info_keywords):
        return "info"
    return "booking"
